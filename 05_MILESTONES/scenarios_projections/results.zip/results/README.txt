* Files are CSV
* Columns are years
* Rows are scenario
* File for par scenario family/variable